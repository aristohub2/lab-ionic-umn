import { User.Model.Ts } from './user.model.ts';

describe('User.Model.Ts', () => {
  it('should create an instance', () => {
    expect(new User.Model.Ts()).toBeTruthy();
  });
});
